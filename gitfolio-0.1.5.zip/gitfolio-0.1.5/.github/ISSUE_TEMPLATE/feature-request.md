---
name: ✨ Feature Request
about: Request a new feature.
---

# What feature should be added?

This feature adds Twitter, Linkedin and Medium links to your profile.

# Why should this feature be added?

Since a portfolio is being made, adding these links help improve the profile better.
